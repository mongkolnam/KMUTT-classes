# SED690_eggs_detection > 2025-02-23 8:34pm
https://universe.roboflow.com/kmuttacth/sed690_eggs_detection

Provided by a Roboflow user
License: CC BY 4.0

