# sikat gigi & sisir > Combs_Toothbrushes
https://universe.roboflow.com/kmuttacth/sikat-gigi-sisir-xfxau

Provided by a Roboflow user
License: CC BY 4.0

