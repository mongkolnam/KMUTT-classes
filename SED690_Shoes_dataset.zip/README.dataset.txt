# shoe_type > 2025-03-08 9:12pm
https://universe.roboflow.com/kmuttacth/shoe_type-xtixl

Provided by a Roboflow user
License: CC BY 4.0

